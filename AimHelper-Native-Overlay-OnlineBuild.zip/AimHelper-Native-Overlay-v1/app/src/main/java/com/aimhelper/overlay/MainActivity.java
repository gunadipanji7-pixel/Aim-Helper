package com.aimhelper.overlay;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button permission = findViewById(R.id.btnOverlayPermission);
        Button start = findViewById(R.id.btnStart);
        Button stop = findViewById(R.id.btnStop);

        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
            } else {
                Toast.makeText(this, "Izin overlay sudah aktif.", Toast.LENGTH_SHORT).show();
            }
        });

        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Aktifkan izin overlay dulu.", Toast.LENGTH_LONG).show();
                return;
            }
            Intent intent = new Intent(this, OverlayService.class);
            startForegroundService(intent);
            Toast.makeText(this, "Aim Helper Overlay aktif.", Toast.LENGTH_SHORT).show();
        });

        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Overlay dimatikan.", Toast.LENGTH_SHORT).show();
        });
    }
}
