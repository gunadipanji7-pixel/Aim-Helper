package com.aimhelper.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class OverlayService extends Service {

    private WindowManager wm;
    private AimCanvas aimCanvas;
    private View panel;
    private boolean enabled = true;

    private static final String CHANNEL = "aim_helper_overlay";

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(7, buildNotification());

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        showOverlay();
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }

        int baseFlags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

        WindowManager.LayoutParams drawParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                baseFlags | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
        );
        drawParams.gravity = Gravity.TOP | Gravity.START;

        aimCanvas = new AimCanvas(this);
        wm.addView(aimCanvas, drawParams);

        TextView control = new TextView(this);
        control.setText("🎯  Aim Helper   ON\n42.3°   •   68% power\nTap here: ON / OFF");
        control.setTextColor(Color.WHITE);
        control.setTextSize(15);
        control.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        control.setPadding(28, 20, 28, 20);
        control.setBackgroundResource(R.drawable.panel_bg);
        control.setOnClickListener(v -> {
            enabled = !enabled;
            control.setText(enabled
                    ? "🎯  Aim Helper   ON\n42.3°   •   68% power\nTap here: ON / OFF"
                    : "🎯  Aim Helper   OFF\nTap here to turn ON");
            if (aimCanvas != null) {
                aimCanvas.invalidate();
            }
        });

        WindowManager.LayoutParams panelParams = new WindowManager.LayoutParams(
                310,
                145,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.TOP | Gravity.END;
        panelParams.x = 18;
        panelParams.y = 75;

        panel = control;
        wm.addView(panel, panelParams);
    }

    private Notification buildNotification() {
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Aim Helper")
                .setContentText("Overlay sedang aktif")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setOngoing(true)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL, "Aim Helper Overlay", NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(c);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (wm != null) {
            if (aimCanvas != null) wm.removeView(aimCanvas);
            if (panel != null) wm.removeView(panel);
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private class AimCanvas extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        AimCanvas(Context c) {
            super(c);
            p.setStrokeCap(Paint.Cap.ROUND);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            if (!enabled) return;

            float w = getWidth();
            float h = getHeight();

            // Demo coordinates intentionally generic; next stage will replace them
            // with real screen detection.
            float cueX = w * 0.50f;
            float cueY = h * 0.76f;
            float targetX = w * 0.50f;
            float targetY = h * 0.46f;
            float pocketX = w * 0.78f;
            float pocketY = h * 0.20f;

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(6);
            p.setColor(Color.rgb(57, 242, 122));
            c.drawLine(cueX, cueY, targetX, targetY, p);

            p.setStrokeWidth(4);
            p.setColor(Color.WHITE);
            float dx = pocketX - targetX;
            float dy = pocketY - targetY;
            float len = (float)Math.sqrt(dx*dx + dy*dy);
            float ux = dx / len, uy = dy / len;
            for (float d = 0; d < len; d += 26) {
                float x1 = targetX + ux*d;
                float y1 = targetY + uy*d;
                float x2 = targetX + ux*Math.min(d+13, len);
                float y2 = targetY + uy*Math.min(d+13, len);
                c.drawLine(x1, y1, x2, y2, p);
            }

            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(90, 57, 242, 122));
            c.drawCircle(targetX, targetY, 27, p);
            p.setColor(Color.rgb(57, 242, 122));
            c.drawCircle(targetX, targetY, 8, p);

            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(5);
            p.setColor(Color.CYAN);
            c.drawCircle(cueX, cueY, 28, p);

            p.setColor(Color.rgb(57, 242, 122));
            c.drawCircle(pocketX, pocketY, 20, p);

            p.setTextSize(36);
            p.setStyle(Paint.Style.FILL);
            c.drawText("42.3°", cueX + 35, cueY - 35, p);
        }
    }
}
