# Cara build Aim Helper dari HP

1. Buat akun/login GitHub.
2. Buat repository baru, misalnya `aim-helper-overlay`.
3. Upload seluruh isi folder project ini ke repository (jangan upload folder pembungkus `AimHelper-Native-Overlay-v1` sebagai satu file ZIP).
4. Buka tab **Actions**.
5. Pilih **Build Aim Helper APK**.
6. Tekan **Run workflow** → **Run workflow**.
7. Tunggu sampai selesai.
8. Buka hasil workflow → bagian **Artifacts** → download `AimHelper-debug-apk`.
9. Ekstrak ZIP artifact dan instal file `.apk` di HP.
