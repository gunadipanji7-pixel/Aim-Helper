# Aim Helper — Native Overlay v1

Tahap 1 ini dibuat untuk menguji kemampuan Android native menampilkan overlay di atas aplikasi lain.

## Cara menjalankan
1. Buka project di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Jalankan ke HP Android.
4. Buka Aim Helper.
5. Tekan **Izinkan tampil di atas aplikasi**.
6. Aktifkan izin.
7. Kembali ke Aim Helper.
8. Tekan **Nyalakan Aim Helper Overlay**.
9. Buka 8 Ball Pool.

## Hasil tahap 1
Akan muncul panel Aim Helper dan garis demo transparan di atas aplikasi lain.

## Tahap berikutnya
- Screenshot/screen capture
- Deteksi meja
- Deteksi cue ball dan bola target
- Deteksi pocket
- Perhitungan titik kontak
- Garis bidik dinamis

Catatan: aplikasi ini hanya memberikan panduan visual. Tidak melakukan auto-click, auto-shot, atau mengendalikan permainan.
